# Real Robot

## Terminal 1
- Switch to your catkin directory
- `$ source devel/setup.bash`
- `$ roslaunch ur3_driver ur3_driver.launch`
 
## Terminal 2
- Switch to your catkin directory
- `$ source devel/setup.bash`
- `$ rosrun lab3pkg_py lab3_exec.py 0 0 0 0 0 0`

